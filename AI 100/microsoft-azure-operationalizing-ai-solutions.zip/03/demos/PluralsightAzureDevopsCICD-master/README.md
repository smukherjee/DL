### Git repository for Pluralsight Course - Operationalizing AI


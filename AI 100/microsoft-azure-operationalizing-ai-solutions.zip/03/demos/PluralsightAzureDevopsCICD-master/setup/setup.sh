#!/bin/bash
python --version
#pip install azure-cli==2.0.46
pip install --upgrade azureml-sdk[cli]==0.1.80
pip install azure-cli-core
pip install numpy
pip install azure-storage-blob==2.0.1
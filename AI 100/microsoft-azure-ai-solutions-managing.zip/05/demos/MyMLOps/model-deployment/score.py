import json
import numpy as np
from sklearn.externals import joblib
from sklearn.linear_model import Ridge
from azureml.core.model import Model

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType

from azureml.monitoring import ModelDataCollector

def init():
    global inputs_dc, prediction_dc
    inputs_dc = ModelDataCollector("mymodel", identifier="inputs", feature_names=["AGE", "SEX", "BMI", "BP", "S1", "S2", "S3", "S4", "S5", "S6"])
    prediction_dc = ModelDataCollector("mymodel", identifier="predictions", feature_names=["prediction1"])

    global model
    model_path = Model.get_model_path('mymodel')
    model = joblib.load(model_path)

input_sample = np.array([[10, 9, 8, 7, 6, 5, 4, 3, 2, 1]])
output_sample = np.array([3726.995])


@input_schema('data', NumpyParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        data = np.array(data)
        result = model.predict(data)
        inputs_dc.collect(data) #this call is saving our input data into Azure Blob
        prediction_dc.collect(result) #this call is saving our input data into Azure Blob    
        # you can return any datatype as long as it is JSON-serializable
        return result.tolist()
    except Exception as e:
        error = str(e)
        return error

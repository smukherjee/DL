# Ref: https://docs.microsoft.com/en-us/azure/role-based-access-control/tutorial-custom-role-powershell

# Ref:https://docs.microsoft.com/en-us/azure/machine-learning/service/how-to-assign-roles

Get-AzProviderOperation 'Microsoft.MachineLearningServices/workspace/*' | Format-Table -Property Operation, Description -AutoSize

Get-AzRoleDefinition -Name 'Reader' | ConvertTo-Json | Out-File 'D:\PSDataScientistRole.json'

code 'D:\PSDataScientistRole.json'

Get-AzSubscription | Select-Object -Property name, id

New-AzRoleDefinition -InputFile 'D:\PSDataScientistRole.json'

